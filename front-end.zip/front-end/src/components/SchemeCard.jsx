const SchemeCard = ({ scheme }) => {
  return (
    <div className="bg-white rounded-xl shadow-md p-4">
      <h2 className="text-xl font-semibold mb-2">{scheme.name}</h2>
      <p className="text-gray-600">{scheme.description}</p>
    </div>
  );
};

export default SchemeCard;
