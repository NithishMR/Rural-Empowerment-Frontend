export default [
  {
    title: "Start a Dairy Business",
    description:
      "Use government microloans to buy 2 cows and start milk supply to local shops.",
    tips: [
      "Apply for the PMEGP scheme (Prime Minister’s Employment Generation Programme).",
      "Save 10% of earnings monthly for emergencies.",
      "Talk to your local cooperative bank for low-interest loans.",
    ],
  },
  {
    title: "Save ₹500/month for Education",
    description:
      "Build a safe education fund over 5 years using recurring deposits.",
    tips: [
      "Open a Recurring Deposit (RD) account at a nearby bank.",
      "Deposit ₹500 monthly.",
      "After 5 years, withdraw around ₹33,000–₹35,000 including interest.",
    ],
  },
  {
    title: "Start a Dairy Business",
    description:
      "Use government microloans to buy 2 cows and start milk supply to local shops.",
    tips: [
      "Apply for the PMEGP scheme (Prime Minister’s Employment Generation Programme).",
      "Save 10% of earnings monthly for emergencies.",
      "Talk to your local cooperative bank for low-interest loans.",
    ],
  },
  // add others similarly...
];
